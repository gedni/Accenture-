import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular 4';
}
//This Key word Example//
function company(name,number){
                     this.name = name;
                     this.number = number;
                         } 
         var MNC = new company("Microsoft", 9912137637);
         var BPO = new company("Accenture", 900000080);
         document.write(MNC.name);
//let Key word Example//         

var doWork = function (flag) {
    if (flag) {
        var x = 3;
    }
    return x;
};
var result = doWork(true);

console.log('var function scope');
console.log(result);


var doWork1 = function (flag) {
    if (flag) {
        let x = 3;
    }
    return x;
};
var result1 = doWork1(true);

console.log('let function scope');
console.log(result1);


//Write a function which accepts an array of strings and returns a map of character to count of the character(including spaces and special characters).//

function char_count(str, letter) 
{
 var letter_Count = 0;
 for (var position = 0; position < str.length; position++) 
 {
    if (str.charAt(position) == letter) 
      {
      letter_Count += 1;
      }
  }
  return letter_Count;
}

console.log(char_count('Microsoft.com', 'o'));

  // Write a function to return all the keys present in an object at any level.//

Object.byString = function(o, s) {
    s = s.replace(/\[(\w+)\]/g, '.$1'); // convert indexes to properties
    s = s.replace(/^\./, '');           // strip a leading dot
    var a = s.split('.');
    for (var i = 0, n = a.length; i < n; ++i) {
        var k = a[i];
        if (k in o) {
            o = o[k];
        } else {
            return;
        }
    }
    return o;
}

console.log(Object.byString(someObject, 'part1.name'));
console.log(Object.byString(someObject, 'part2.qty'));
console.log(Object.byString(someObject, 'part3[0].name'));
            
//Write a function to reverse every word of a string Using split and reverse//

function reverseString(str){
  let revSrring = "";
  str.split("").forEach(function(char){
         revSrring = char + revSrring;
      });
      return revSrring;
    }
alert(reverseString("Microsoft and Accenture"));     

//Without using split and reverse and in O(1) space (since strings are immutable, assume that the input is a character array).
function palindrome(str) {

    var len = str.length;
    var mid = Math.floor(len/2);

    for ( var i = 0; i < mid; i++ ) {
        if (str[i] !== str[len - 1 - i]) {
            return false;
        }
    }

    return true;
}




// Write a function to remove duplicate strings from an array of strings.

var duplicatedArray = [1, 2, 3, 4, 5, 1, 1, 1, 2, 3, 4];
var uniqueArray = Array.from(new Set(duplicatedArray));

console.log(uniqueArray);